<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAdminIdToAllTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::table('users', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });

        Schema::table('assessments', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('groups', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('colors', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('participantes', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('assessment_results', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('assessment_scorings', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('grades', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('events', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('faqs', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('percentiles', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('settings', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
        Schema::table('facilitator_instructions', function (Blueprint $table) {
            $table->integer('admin_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::table('users', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });

        Schema::table('assessments', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('groups', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('colors', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('participantes', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('assessment_results', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('assessment_scorings', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('grades', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('events', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('faqs', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('percentiles', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('settings', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
        Schema::table('facilitator_instructions', function (Blueprint $table) {
          $table->integer('admin_id')->nullable();
        });
    }
}
