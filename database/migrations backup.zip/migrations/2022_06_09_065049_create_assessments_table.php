<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAssessmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessments', function (Blueprint $table) {
            $table->increments('id');
            $table->string('Name')->nullable();
            $table->string('ShortName')->nullable();
            $table->string('NickName')->nullable();
            $table->string('Abbr')->nullable();
            $table->longText('Setup')->nullable();
            $table->longText('Instructions')->nullable();
            $table->longText('EvalList')->nullable();
            $table->integer('MaxParticipants')->nullable();
            $table->string('Image')->nullable();
            $table->string('Type')->nullable();
            $table->integer('Sort')->nullable();
            $table->integer('Status')->delfault(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessments');
    }
}
